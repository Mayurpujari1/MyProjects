# place-to-stay
MERN Project  
This project was created for [Youtube Lessons](https://www.youtube.com/watch?v=ANZNMaBODDY&list=PLufbXXGswL_pS6rdWbDO56oiZovLWE_rs).
