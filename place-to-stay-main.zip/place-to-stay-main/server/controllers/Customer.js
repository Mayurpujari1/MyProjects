import Customer from '../models/Customer.js';
import tryCatch from './utils/tryCatch.js';

export const createCustomer = tryCatch(async (req, res) => {
  const { id: uid, name: uName } = req.user;
  const newCustomer = new Customer({ ...req.body, uid, uName});
  await newCustomer.save();
  res.status(201).json({ success: true, result: newCustomer });
});

export const getCustomers = tryCatch(async (req, res) => {
  const Customers = await Customer.find().sort({ _id: -1 });
  res.status(200).json({ success: true, result: Customers });
});

export const deleteCustomer = tryCatch(async (req, res) => {
  const { _id } = await Customer.findByIdAndDelete(req.params.CustomerId);
  res.status(200).json({ success: true, result: { _id } });
});

export const updateCustomer = tryCatch(async (req, res) => {
  const updatedCustomer = await Customer.findByIdAndUpdate(
    req.params.CustomerId,
    req.body,
    { new: true }
  );
  res.status(200).json({ success: true, result: updatedCustomer });
});
