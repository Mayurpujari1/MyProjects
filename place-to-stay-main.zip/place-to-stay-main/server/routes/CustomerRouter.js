import { Router } from 'express';
import {
    getCustomers,
  createCustomer,
  deleteCustomer,
  updateProfile,
  updateStatus,
} from '../controllers/Customer.js';
import auth from '../middleware/auth.js';
import checkAccess from '../middleware/checkAccess.js';
import CustomerPermissions from '../middleware/permissions/Customer/CustomerPermissions.js';
import Customer from '../../client/src/pages/dashboard/Customers/Customer.js';

const CustomerRouter = Router();
CustomerRouter.post('/register', register);
CustomerRouter.post('/login', login);
CustomerRouter.post('/customer', Customer);
CustomerRouter.patch('/updateProfile', auth, updateProfile);
CustomerRouter.get('/', auth, checkAccess(CustomerPermissions.listCustomers), getCustomers);
CustomerRouter.patch(
  '/updateStatus/:CustomerId',
  auth,
  checkAccess(CustomerPermissions.updateStatus),
  updateStatus
);

export default CustomerRouter;